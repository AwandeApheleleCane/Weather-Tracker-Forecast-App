package com.example.weatherforecasttrackerapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}
class MainActivity : AppCompatActivity() {

    // Define a data class to store weather information for each day
    data class WeatherData(
        val day: String,
        val temperature: Double,
        val conditions: String
    )

    // Create a list of WeatherData objects to store weather information for the week
    private val weeklyWeather = listOf(
        WeatherData("Monday", 25.0, "Sunny"),
        WeatherData("Tuesday", 23.5, "Cloudy"),
        WeatherData("Wednesday", 27.5, "Rainy"),
        WeatherData("Thursday", 24.0, "Partly Cloudy"),
        WeatherData("Friday", 26.0, "Thunderstorm"),
        WeatherData("Saturday", 29.0, "Sunny"),
        WeatherData("Sunday", 22.5, "Foggy")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Display the average temperature for the week
        try {
            val averageTemperature = calculateAverageTemperature()
            Toast.makeText(this, "Average Temperature for the Week: $averageTemperature °C", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Error calculating average temperature: ${e.message}", Toast.LENGTH_SHORT).show()
        }

        // Display detailed weather information for a selected day (e.g., Thursday)
        val selectedDay = "Thursday"
        val dayWeather = displayDayWeather(selectedDay)
        dayWeather?.let {
            Toast.makeText(this, "Weather information for $selectedDay:\nTemperature: ${it.temperature} °C\nConditions: ${it.conditions}", Toast.LENGTH_LONG).show()
        } ?: run {
            Toast.makeText(this, "Weather information not found for $selectedDay", Toast.LENGTH_SHORT).show()
        }
    }

    // Calculate the average temperature for the week with error handling
    private fun calculateAverageTemperature(): Double {
        if (weeklyWeather.isEmpty()) {
            throw Exception("No weather data available")
        }

        var totalTemperature = 0.0
        for (weather in weeklyWeather) {
            totalTemperature += weather.temperature
        }
        return totalTemperature / weeklyWeather.size
    }

    // Display detailed weather information for a selected day
    private fun displayDayWeather(day: String): WeatherData? {
        return weeklyWeather.find { it.day == day }
    }
}